const express=require("express");
const router=express.Router();
const mysql=require("../DB/DBConnection.js");

router.get("/api/employee", (req, resp)=>{
    mysql.query("select * from emps", (err, data)=>{
        if(err)
            resp.status(404).send("error : "+JSON.stringify(err));
        else
            resp.send(data);
    });
});

router.get("/api/employee/:empID", (req, resp)=>{
    mysql.query("select * from emps where empID=?", req.params.empID, (err, data)=>{
        if(err)
            resp.status(500).send("error : "+JSON.stringify(err));
        else
            resp.send(data);
    });
});

router.post("/api/employee/add", (req, resp)=>{
    var empID=req.body.empId;
    var empName=req.body.empName;
    var email=req.body.emailId;

    mysql.query("insert into emps values(?,?,?)", [empID, empName, email], (err, data)=>{
        console.log(data);
        if(err)
            resp.status(500).send("fail to add data in database...");
        else
            resp.send("employees details added :: \n");
    });
});

router.delete("/api/employee/remove/:empID", (req, resp)=>{
    mysql.query("delete from emps where empId=?", req.params.empID, (err, data)=>{
        if(err)
            resp.status(500).send("fail to remove employee...");
        else
            resp.status(200).send("employee removed successfully...");
    });
});



module.exports=router;
