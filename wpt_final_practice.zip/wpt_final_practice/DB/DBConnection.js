const mysql=require("mysql");

const conn=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"root",
    database:"wpt",
    post:3306
});

//Optional
conn.connect((err)=>{
    if(err)
        console.log("connection failed "+JSON.stringify(err));
    else
        console.log("connected...");
});

module.exports=conn;