//import all required modules
const express=require("express");
const app=express();
const bodyParser=require("body-parser");
const router=require("./Router/routers.js");

//add required middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

//add custom middleware
app.use("/", router);


app.listen(4004, ()=>{
    console.log("server is started at port no 4004");
});

module.exports=app;

